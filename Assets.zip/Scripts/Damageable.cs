using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damageable : MonoBehaviour
{
    [Header("Damage, KnockBack")]
    [SerializeField] private float damage; // ��Ʈ�ڽ��� �� ������
    [SerializeField] private float knockbackPower; // �˹� ����

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            // ������ �������� �ְ� �˹��� �����ϱ�~
            var enemy = collision.GetComponent<Distant>();
            if (enemy != null)
            {
                enemy.health -= damage; // ü�� ����
                ApplyKnockback(collision.transform.position, knockbackPower, collision.GetComponent<Rigidbody2D>());
                enemy.UpdateState(EState.Hitted);
            }
        }
    }

    public void ApplyKnockback(Vector2 hitPosition, float knockbackPower, Rigidbody2D enemyRigidbody)
    {
        if (enemyRigidbody != null)
        {
            Vector2 knockbackDirection = ((Vector2)enemyRigidbody.transform.position - hitPosition).normalized;
            enemyRigidbody.AddForce(knockbackDirection * knockbackPower, ForceMode2D.Impulse);
        }
    }
}

