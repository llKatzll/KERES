using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationStrings : MonoBehaviour
{
    public static string IsMove = "isMove";
    public static string Jump = "Jump";
    public static string IsGrounded = "isGrounded";
    public static string Dash = "Dash";

    public static string Attack = "Attack";
}
